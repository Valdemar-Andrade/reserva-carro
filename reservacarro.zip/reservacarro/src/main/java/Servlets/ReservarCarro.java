/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import DAO.ReservaCarroDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.ReservaCarro;
import utils.DatasHorasAluguel;
import utils.LocalizacaoRetirada;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "ReservarCarro", urlPatterns = {"/ReservarCarro"})
public class ReservarCarro extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (request.getServletPath().equalsIgnoreCase("/ReservarCarro")) {
            
            int pk_pessoa = Integer.parseInt(request.getParameter("pk_pessoa"));
            int pk_carro = Integer.parseInt(request.getParameter("pk_carro"));
            float valor_pago = Float.parseFloat(request.getParameter("valor_pago"));
            int pk_localizacao = LocalizacaoRetirada.pk_municipio;
            int pk_metodo_pagamento = Integer.parseInt(request.getParameter("metodo-pagamento"));
            
            ReservaCarro reserva = new ReservaCarro();
            
            if (pk_pessoa != 0 && pk_carro != 0 && pk_localizacao != 0 && pk_metodo_pagamento != 0 && valor_pago != 0.0) {
                
                reserva.setFk_pessoa(pk_pessoa);
                reserva.setFk_carro(pk_carro);
                reserva.setFk_localizacao_retirada(pk_localizacao);
                reserva.setFk_metodo_pagamento(pk_metodo_pagamento);
                reserva.setValor_pago(valor_pago);
                reserva.setData_hora_retirada(DatasHorasAluguel.getDataHoraRetirada());
                reserva.setData_hora_entrega(DatasHorasAluguel.getDataHoraDevolucao());
                
                ReservaCarroDAO reservarDAO = new ReservaCarroDAO();
                reservarDAO.cadastrarReservaCarro(reserva);
            } else {
                //response.sendRedirect("index.jsp");
            }
            
            response.sendRedirect("index.jsp");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
