/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import utils.DadosConsulta;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "ConsultarClientes", urlPatterns = {"/ConsultarClientes"})
public class ConsultarClientes extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        if (request.getServletPath().equalsIgnoreCase("/ConsultarClientes")) {

            String data1 = request.getParameter("data-inicio").trim() + " " + request.getParameter("hora-inicio").trim();
            String data2 = request.getParameter("data-fim").trim() + " " + request.getParameter("hora-fim").trim();

            if (!data1.isEmpty() && !data2.isEmpty()) {

                Timestamp dataHoraR, dataHoraD;

                String pattern = "yyyy-MM-dd HH:mm";
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);

                LocalDateTime dataR = LocalDateTime.from(formatter.parse(data1));
                LocalDateTime dataD = LocalDateTime.from(formatter.parse(data2));

                dataHoraR = Timestamp.valueOf(dataR);
                dataHoraD = Timestamp.valueOf(dataD);

                DadosConsulta.setData1(dataHoraR);
                DadosConsulta.setData2(dataHoraD);

                response.sendRedirect("consulta.jsp");
                /*
                request.setAttribute("data-inicio", data1);
                request.setAttribute("data-fim", data2);
                
                RequestDispatcher dispatcher = request.getRequestDispatcher("consulta.jsp");
                dispatcher.forward(request, response);
                 */
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
