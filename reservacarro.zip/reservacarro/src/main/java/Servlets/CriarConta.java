/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlets;

import DAO.UsuarioDAO;
import DAO.PessoaDAO;
import DAO.ResidenciaDAO;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Usuario;
import model.Pessoa;
import model.Residencia;

/**
 *
 * @author valdemar
 */
@WebServlet(name = "CriarConta", urlPatterns = {"/CriarConta"})
public class CriarConta extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (request.getServletPath().equalsIgnoreCase("/CriarConta")) {

            String parametro1 = request.getParameter("nome").trim();
            String parametro2 = request.getParameter("numBI").trim();
            String parametro3 = request.getParameter("sexo").trim();
            String parametro4 = request.getParameter("estado-civil").trim();
            String parametro5 = request.getParameter("data-nascimento").trim();
            String parametro6 = request.getParameter("rua").trim();
            String parametro7 = request.getParameter("casa-numero").trim();
            String parametro8 = request.getParameter("provincia").trim();
            String parametro9 = request.getParameter("email").trim();
            String parametro10 = request.getParameter("senha").trim();
            String parametro11 = request.getParameter("confsenha").trim();
            String parametro12 = request.getParameter("altura").trim();
            
            

            //Validacao dos parametros obrigatorios
            if (!parametro1.trim().isEmpty()
                    && !parametro9.trim().isEmpty() && !parametro10.trim().isEmpty() && !parametro11.trim().isEmpty()) {
                
                //As senhas sao iguais
                if (parametro10.equals(parametro11)) {

                    //--------Tratamento dos dados pra conta (o Usuario)--------
                    Usuario usuario = new Usuario();

                    usuario.setEmail(parametro9);
                    usuario.setSenha(parametro10);
                    usuario.setFk_tipo_usuario(1);//cliente -> 1 | admin -> 2

                    UsuarioDAO usuarioDAO = new UsuarioDAO();
                    usuarioDAO.cadastrarUsuario(usuario);

                    //Obter a FK do ultimo usuario pra passar para o cadastro da pessoa
                    int idUsuario = usuarioDAO.pegarUltimoUsuario().getPk_usuario();

                    //------Tratamento dos dados da residencia-------
                    Residencia residencia = new Residencia();

                    int numeroCasa = Integer.parseInt(parametro7);
                    int fkProvincia = Integer.parseInt(parametro8);
                    int fkSexo = Integer.parseInt(parametro3);
                    int fkEstadoCivil = Integer.parseInt(parametro4);

                    residencia.setRua(parametro6);
                    residencia.setNumero_casa(numeroCasa);
                    residencia.setFk_provincia(fkProvincia);

                    ResidenciaDAO residenciaDAO = new ResidenciaDAO();
                    residenciaDAO.cadastrarResidencia(residencia);

                    //Obter a FK da ultima instancia de residencia pra passar para o cadastro pessoa
                    int fkResidencia = residenciaDAO.pegarUltimaResidencia().getPk_residencia();

                    //--------Tratamento dos dados da pessoa--------
                    Pessoa pessoa = new Pessoa();

                    pessoa.setNome(parametro1);
                    pessoa.setFk_usuario(idUsuario);
                    pessoa.setAltura(parametro12);
                    pessoa.setData_nascimento(parametro5);
                    pessoa.setNumero_bi(parametro2);
                    pessoa.setFk_sexo(fkSexo);
                    pessoa.setFk_estado_civil(fkEstadoCivil);
                    pessoa.setFk_residencia(fkResidencia);
                    
                    //JOptionPane.showMessageDialog(null, "Nome: " + pessoa.getNome() + "\nFK Usuario: " + pessoa.getFk_usuario() + "\nAltura: " + pessoa.getAltura() + "\nData Nascimento: " + pessoa.getData_nascimento() + "\nBI: " + pessoa.getNumero_bi() + "\nSexo: " + pessoa.getFk_sexo() + "\nEstado Civil: " + pessoa.getFk_estado_civil() + "\nResidencia: " + pessoa.getFk_residencia());

                    PessoaDAO pessoaDAO = new PessoaDAO();
                    pessoaDAO.cadastrarPessoa(pessoa);
                }
            
            }
            response.sendRedirect("login.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
