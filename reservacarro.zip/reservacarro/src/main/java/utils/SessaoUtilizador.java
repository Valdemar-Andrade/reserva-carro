/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author valdemar
 */
public class SessaoUtilizador {
    public static String tipo_usuario, nome_usuario;
    public static int pk_usuario, pk_pessoa;

    public SessaoUtilizador() {
    }

    public static String getTipo_usuario() {
        return tipo_usuario;
    }

    public static void setTipo_usuario(String tipo_usuario) {
        SessaoUtilizador.tipo_usuario = tipo_usuario;
    }

    public static String getNome_usuario() {
        return nome_usuario;
    }

    public static void setNome_usuario(String nome_usuario) {
        SessaoUtilizador.nome_usuario = nome_usuario;
    }

    
    
}
