/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.sql.Timestamp;


/**
 *
 * @author valdemar
 */
public class DatasHorasAluguel {
    
    public static Timestamp dataHoraRetirada, dataHoraDevolucao;

    public DatasHorasAluguel() {
    }

    public static Timestamp getDataHoraRetirada() {
        return dataHoraRetirada;
    }

    public static void setDataHoraRetirada(Timestamp dataHoraRetirada) {
        DatasHorasAluguel.dataHoraRetirada = dataHoraRetirada;
    }

    public static Timestamp getDataHoraDevolucao() {
        return dataHoraDevolucao;
    }

    public static void setDataHoraDevolucao(Timestamp dataHoraDevolucao) {
        DatasHorasAluguel.dataHoraDevolucao = dataHoraDevolucao;
    }
    
    
}
