/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.sql.Timestamp;

/**
 *
 * @author valdemar
 */
public class DadosConsulta {
    
    public static Timestamp data1, data2;

    public DadosConsulta() {
    }

    public static Timestamp getData1() {
        return data1;
    }

    public static void setData1(Timestamp data1) {
        DadosConsulta.data1 = data1;
    }

    public static Timestamp getData2() {
        return data2;
    }

    public static void setData2(Timestamp data2) {
        DadosConsulta.data2 = data2;
    }
    
    
}
