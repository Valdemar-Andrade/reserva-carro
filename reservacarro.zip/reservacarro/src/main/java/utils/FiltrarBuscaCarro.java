/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

/**
 *
 * @author valdemar
 */
public class FiltrarBuscaCarro {
    
    public static String tipo_filtro;

    public FiltrarBuscaCarro() {
    }

    public static String getTipo_filtro() {
        return FiltrarBuscaCarro.tipo_filtro;
    }

    public static void setTipo_filtro(String tipo_filtro) {
        FiltrarBuscaCarro.tipo_filtro = tipo_filtro;
    }
    
    
    
}
