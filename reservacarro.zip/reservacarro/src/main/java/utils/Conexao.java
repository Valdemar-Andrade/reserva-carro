/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author valdemar
 */
public class Conexao {

    private static String url = "jdbc:postgresql://localhost/reservacarro";
    private static String user = "postgres";
    private static String password = "";

    public static Connection abrirConexao() {
        Connection conexao = null;

        try {
            Class.forName("org.postgresql.Driver");
            
            
            conexao = DriverManager.getConnection(url, user, password);
            
            
        } catch (SQLException e) {
            System.out.println("Erro ao conectar a base de dados");
        } catch (ClassNotFoundException ex) {
            System.out.println("Erro ao procurar o driver jdbc");
        }

        return conexao;
    }

}
