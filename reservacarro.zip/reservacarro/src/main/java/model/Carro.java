/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Carro {
    int pk_carro, fk_modelo, fk_classe, numero_lugares;
    float preco;
    
    //
    String marca, modelo, classe;

    public Carro(String modelo, String classe) {
        this.modelo = modelo;
        this.classe = classe;
    }

    public Carro() {
    }

    public Carro(int pk_carro, int fk_modelo, int fk_classe, int numero_lugares, float preco) {
        this.pk_carro = pk_carro;
        this.fk_modelo = fk_modelo;
        this.fk_classe = fk_classe;
        this.numero_lugares = numero_lugares;
        this.preco = preco;
    }

    public int getPk_carro() {
        return pk_carro;
    }

    public void setPk_carro(int pk_carro) {
        this.pk_carro = pk_carro;
    }

    public int getFk_modelo() {
        return fk_modelo;
    }

    public void setFk_modelo(int fk_modelo) {
        this.fk_modelo = fk_modelo;
    }

    public int getFk_classe() {
        return fk_classe;
    }

    public void setFk_classe(int fk_classe) {
        this.fk_classe = fk_classe;
    }

    public int getNumero_lugares() {
        return numero_lugares;
    }

    public void setNumero_lugares(int numero_lugares) {
        this.numero_lugares = numero_lugares;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getClasse() {
        return classe;
    }

    public void setClasse(String classe) {
        this.classe = classe;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
    
    
}
