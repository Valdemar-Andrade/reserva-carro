/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Provincia {
    int pk_provincia;
    String nome;

    public Provincia() {
    }
    
    public Provincia(int pk_provincia, String nome) {
        this.pk_provincia = pk_provincia;
        this.nome = nome;
    }

    public int getPk_provincia() {
        return pk_provincia;
    }

    public void setPk_provincia(int pk_provincia) {
        this.pk_provincia = pk_provincia;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
