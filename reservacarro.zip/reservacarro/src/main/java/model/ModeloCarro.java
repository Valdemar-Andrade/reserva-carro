/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class ModeloCarro {
    int pk_modelo_marca, fk_marca_carro;
    String nome;

    public ModeloCarro() {
    }

    public ModeloCarro(int pk_modelo_marca, int fk_marca_carro, String nome) {
        this.pk_modelo_marca = pk_modelo_marca;
        this.fk_marca_carro = fk_marca_carro;
        this.nome = nome;
    }

    public int getPk_modelo_marca() {
        return pk_modelo_marca;
    }

    public void setPk_modelo_marca(int pk_modelo_carro) {
        this.pk_modelo_marca = pk_modelo_carro;
    }

    public int getFk_marca_carro() {
        return fk_marca_carro;
    }

    public void setFk_marca_carro(int fk_marca_carro) {
        this.fk_marca_carro = fk_marca_carro;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
