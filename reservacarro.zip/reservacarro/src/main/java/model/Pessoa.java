/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Pessoa {
    int pk_pessoa, fk_usuario, fk_residencia, fk_sexo, fk_estado_civil;
    String nome, data_nascimento, numero_bi, altura;

    public Pessoa(int pk_pessoa, int fk_usuario, int fk_residencia, String nome, int fk_sexo, int fk_estado_civil, String data_nascimento, String numero_bi, String altura) {
        this.pk_pessoa = pk_pessoa;
        this.fk_usuario = fk_usuario;
        this.fk_residencia = fk_residencia;
        this.nome = nome;
        this.fk_sexo = fk_sexo;
        this.fk_estado_civil = fk_estado_civil;
        this.data_nascimento = data_nascimento;
        this.numero_bi = numero_bi;
        this.altura = altura;
    }

    public Pessoa() {
    }

    public int getPk_pessoa() {
        return pk_pessoa;
    }

    public void setPk_pessoa(int pk_pessoa) {
        this.pk_pessoa = pk_pessoa;
    }

    public int getFk_usuario() {
        return fk_usuario;
    }

    public void setFk_usuario(int fk_usuario) {
        this.fk_usuario = fk_usuario;
    }

    public int getFk_residencia() {
        return fk_residencia;
    }

    public void setFk_residencia(int fk_residencia) {
        this.fk_residencia = fk_residencia;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getFk_sexo() {
        return fk_sexo;
    }

    public void setFk_sexo(int fk_sexo) {
        this.fk_sexo = fk_sexo;
    }

    public int getFk_estado_civil() {
        return fk_estado_civil;
    }

    public void setFk_estado_civil(int fk_estado_civil) {
        this.fk_estado_civil = fk_estado_civil;
    }

    public String getData_nascimento() {
        return data_nascimento;
    }

    public void setData_nascimento(String data_nascimento) {
        this.data_nascimento = data_nascimento;
    }

    public String getNumero_bi() {
        return numero_bi;
    }

    public void setNumero_bi(String numero_bi) {
        this.numero_bi = numero_bi;
    }

    public String getAltura() {
        return altura;
    }

    public void setAltura(String altura) {
        this.altura = altura;
    }
    
    
    
}
