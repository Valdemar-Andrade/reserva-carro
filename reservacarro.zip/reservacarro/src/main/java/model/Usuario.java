/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Usuario {
    int pk_usuario, fk_tipo_usuario;
    String email, senha;

    public Usuario() {
    }

    public Usuario(int pk_usuario, int fk_tipo_usuario, String email, String senha) {
        this.pk_usuario = pk_usuario;
        this.fk_tipo_usuario = fk_tipo_usuario;
        this.email = email;
        this.senha = senha;
    }

    public int getPk_usuario() {
        return pk_usuario;
    }

    public void setPk_usuario(int pk_usuario) {
        this.pk_usuario = pk_usuario;
    }

    public int getFk_tipo_usuario() {
        return fk_tipo_usuario;
    }

    public void setFk_tipo_usuario(int fk_tipo_usuario) {
        this.fk_tipo_usuario = fk_tipo_usuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    
}
