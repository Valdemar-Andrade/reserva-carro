/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Municipio {
    int pk_municipio, fk_provincia;
    String nome;

    public Municipio() {
    }

    public Municipio(int pk_municipio, int fk_provincia, String nome) {
        this.fk_provincia = fk_provincia;
        this.pk_municipio = pk_municipio;
        this.nome = nome;
    }

    public int getPk_municipio() {
        return pk_municipio;
    }

    public void setPk_municipio(int pk_municipio) {
        this.pk_municipio = pk_municipio;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getFk_provincia() {
        return fk_provincia;
    }

    public void setFk_provincia(int fk_provincia) {
        this.fk_provincia = fk_provincia;
    }
    
    
}
