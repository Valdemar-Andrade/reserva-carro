/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Timestamp;

/**
 *
 * @author valdemar
 */
public class PessoaAluguel {
    
    String nome, modelo_carro, classe_carro;
    Timestamp data_hora_retirada, data_hora_entrega;
    
    int pk_pessoa, pk_reserva, pk_carro, numero_lugares;
    float preco;

    public PessoaAluguel(String nome, String modelo_carro, String classe_carro, Timestamp data_hora_retirada, Timestamp data_hora_entrega, int pk_pessoa, int pk_reserva, int pk_carro, int numero_lugares, float preco) {
        this.nome = nome;
        this.modelo_carro = modelo_carro;
        this.classe_carro = classe_carro;
        this.data_hora_retirada = data_hora_retirada;
        this.data_hora_entrega = data_hora_entrega;
        this.pk_pessoa = pk_pessoa;
        this.pk_reserva = pk_reserva;
        this.pk_carro = pk_carro;
        this.numero_lugares = numero_lugares;
        this.preco = preco;
    }

    public PessoaAluguel() {
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getModelo_carro() {
        return modelo_carro;
    }

    public void setModelo_carro(String modelo_carro) {
        this.modelo_carro = modelo_carro;
    }

    public String getClasse_carro() {
        return classe_carro;
    }

    public void setClasse_carro(String classe_carro) {
        this.classe_carro = classe_carro;
    }

    public Timestamp getData_hora_retirada() {
        return data_hora_retirada;
    }

    public void setData_hora_retirada(Timestamp data_hora_retirada) {
        this.data_hora_retirada = data_hora_retirada;
    }

    public Timestamp getData_hora_entrega() {
        return data_hora_entrega;
    }

    public void setData_hora_entrega(Timestamp data_hora_entrega) {
        this.data_hora_entrega = data_hora_entrega;
    }

    public int getPk_pessoa() {
        return pk_pessoa;
    }

    public void setPk_pessoa(int pk_pessoa) {
        this.pk_pessoa = pk_pessoa;
    }

    public int getPk_reserva() {
        return pk_reserva;
    }

    public void setPk_reserva(int pk_reserva) {
        this.pk_reserva = pk_reserva;
    }

    public int getPk_carro() {
        return pk_carro;
    }

    public void setPk_carro(int pk_carro) {
        this.pk_carro = pk_carro;
    }

    public int getNumero_lugares() {
        return numero_lugares;
    }

    public void setNumero_lugares(int numero_lugares) {
        this.numero_lugares = numero_lugares;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }
    
    
    
    
}
