/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Timestamp;

/**
 *
 * @author valdemar
 */
public class ReservaCarro {
    int pk_reserva, fk_pessoa, fk_localizacao_retirada, fk_carro, fk_metodo_pagamento;
    Timestamp data_hora_retirada, data_hora_entrega;
    float valor_pago;

    public ReservaCarro() {
    }

    public ReservaCarro(int pk_reserva, int fk_pessoa, int fk_localizacao_retirada, int fk_carro, int fk_metodo_pagamento, Timestamp data_hora_retirada, Timestamp data_hora_entrega, float valor_pago) {
        this.pk_reserva = pk_reserva;
        this.fk_pessoa = fk_pessoa;
        this.fk_localizacao_retirada = fk_localizacao_retirada;
        this.fk_carro = fk_carro;
        this.fk_metodo_pagamento = fk_metodo_pagamento;
        this.data_hora_retirada = data_hora_retirada;
        this.data_hora_entrega = data_hora_entrega;
        this.valor_pago = valor_pago;
    }

    public int getPk_reserva() {
        return pk_reserva;
    }

    public void setPk_reserva(int pk_reserva) {
        this.pk_reserva = pk_reserva;
    }

    public int getFk_pessoa() {
        return fk_pessoa;
    }

    public void setFk_pessoa(int fk_pessoa) {
        this.fk_pessoa = fk_pessoa;
    }

    public int getFk_localizacao_retirada() {
        return fk_localizacao_retirada;
    }

    public void setFk_localizacao_retirada(int fk_localizacao_retirada) {
        this.fk_localizacao_retirada = fk_localizacao_retirada;
    }

    public int getFk_carro() {
        return fk_carro;
    }

    public void setFk_carro(int fk_carro) {
        this.fk_carro = fk_carro;
    }

    public int getFk_metodo_pagamento() {
        return fk_metodo_pagamento;
    }

    public void setFk_metodo_pagamento(int fk_metodo_pagamento) {
        this.fk_metodo_pagamento = fk_metodo_pagamento;
    }

    public Timestamp getData_hora_retirada() {
        return data_hora_retirada;
    }

    public void setData_hora_retirada(Timestamp data_hora_retirada) {
        this.data_hora_retirada = data_hora_retirada;
    }

    public Timestamp getData_hora_entrega() {
        return data_hora_entrega;
    }

    public void setData_hora_entrega(Timestamp data_hora_entrega) {
        this.data_hora_entrega = data_hora_entrega;
    }

    public float getValor_pago() {
        return valor_pago;
    }

    public void setValor_pago(float valor_pago) {
        this.valor_pago = valor_pago;
    }
    
    public String getDataHoraRetiradaFormatada(){
        return data_hora_retirada.toString();
    }
    
    public String getDataHoraEntregaFormatada(){
        return data_hora_entrega.toString();
    }
    
}
