/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class ClasseCarro {
    int pk_classe_carro;
    String nome;

    public ClasseCarro() {
    }

    public ClasseCarro(int pk_classe_carro, String nome) {
        this.pk_classe_carro = pk_classe_carro;
        this.nome = nome;
    }
    
    public int getPk_classe_carro() {
        return pk_classe_carro;
    }

    public void setPk_classe_carro(int pk_classe_carro) {
        this.pk_classe_carro = pk_classe_carro;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
