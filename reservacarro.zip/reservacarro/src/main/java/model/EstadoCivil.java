/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class EstadoCivil {
    int pk_estado_civil;
    String nome;

    public EstadoCivil() {
    }

    public EstadoCivil(int pk_estado_civil, String nome) {
        this.pk_estado_civil = pk_estado_civil;
        this.nome = nome;
    }

    public int getPk_estado_civil() {
        return pk_estado_civil;
    }

    public void setPk_estado_civil(int pk_estado_civil) {
        this.pk_estado_civil = pk_estado_civil;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
