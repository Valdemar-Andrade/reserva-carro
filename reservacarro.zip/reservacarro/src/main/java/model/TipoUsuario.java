/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class TipoUsuario {
    int pk_tipo_usuario;
    String nome;

    public TipoUsuario() {
    }

    public TipoUsuario(int pk_tipo_usuario, String nome) {
        this.pk_tipo_usuario = pk_tipo_usuario;
        this.nome = nome;
    }

    public int getPk_tipo_usuario() {
        return pk_tipo_usuario;
    }

    public void setPk_tipo_usuario(int pk_tipo_usuario) {
        this.pk_tipo_usuario = pk_tipo_usuario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
