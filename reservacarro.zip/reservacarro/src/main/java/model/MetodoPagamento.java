/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class MetodoPagamento {
    int pk_metodo_pagamento;
    String nome;

    public MetodoPagamento() {
    }

    public MetodoPagamento(int pk_metodo_pagamento, String nome) {
        this.pk_metodo_pagamento = pk_metodo_pagamento;
        this.nome = nome;
    }

    public int getPk_metodo_pagamento() {
        return pk_metodo_pagamento;
    }

    public void setPk_metodo_pagamento(int pk_metodo_pagamento) {
        this.pk_metodo_pagamento = pk_metodo_pagamento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
