/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Sexo {
    int pk_sexo;
    String nome;

    public Sexo() {
    }

    public Sexo(int pk_sexo, String nome) {
        this.pk_sexo = pk_sexo;
        this.nome = nome;
    }

    public int getPk_sexo() {
        return pk_sexo;
    }

    public void setPk_sexo(int pk_sexo) {
        this.pk_sexo = pk_sexo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
