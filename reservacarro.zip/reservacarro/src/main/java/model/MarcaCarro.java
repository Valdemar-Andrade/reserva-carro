/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class MarcaCarro {
    int pk_marca_carro;
    String nome;

    public MarcaCarro() {
    }

    public MarcaCarro(int pk_marca_carro, String nome) {
        this.pk_marca_carro = pk_marca_carro;
        this.nome = nome;
    }

    public int getPk_marca_carro() {
        return pk_marca_carro;
    }

    public void setPk_marca_carro(int pk_marca_carro) {
        this.pk_marca_carro = pk_marca_carro;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
}
