/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author valdemar
 */
public class Residencia {
    int pk_residencia, fk_provincia, numero_casa;
    String rua;

    public Residencia() {
    }

    public Residencia(int pk_residencia, int fk_provincia, int numero_casa, String rua) {
        this.pk_residencia = pk_residencia;
        this.fk_provincia = fk_provincia;
        this.numero_casa = numero_casa;
        this.rua = rua;
    }

    public int getPk_residencia() {
        return pk_residencia;
    }

    public void setPk_residencia(int pk_residencia) {
        this.pk_residencia = pk_residencia;
    }

    public int getFk_provincia() {
        return fk_provincia;
    }

    public void setFk_provincia(int fk_provincia) {
        this.fk_provincia = fk_provincia;
    }

    public int getNumero_casa() {
        return numero_casa;
    }

    public void setNumero_casa(int numero_casa) {
        this.numero_casa = numero_casa;
    }

    public String getRua() {
        return rua;
    }

    public void setRua(String rua) {
        this.rua = rua;
    }
    
    
}
