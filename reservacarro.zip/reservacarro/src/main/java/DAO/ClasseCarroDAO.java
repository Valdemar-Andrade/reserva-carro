/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.ClasseCarro;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class ClasseCarroDAO {

    public boolean cadastrarClasseCarro(ClasseCarro classe) {

        String query_insert = "INSERT INTO classe_carro VALUES (DEFAULT, ?);";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setString(1, classe.getNome());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }

    public void atualizarClasse(String novaModelo, int pk_modelo) {
        String query = "update classe_carro set nome=? where pk_classe = ?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, novaModelo);
            ps.setInt(2, pk_modelo);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public void eliminar(int pk) {
        String query = "delete from classe where pk_classe = ?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public ArrayList<ClasseCarro> listarClasseCarro() {
        ArrayList<ClasseCarro> classes = new ArrayList<>();
        String query = "SELECT pk_classe, nome FROM classe_carro";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ClasseCarro classe = new ClasseCarro();

                classe.setPk_classe_carro(rs.getInt(1));
                classe.setNome(rs.getString(2));

                classes.add(classe);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return classes;
    }

}
