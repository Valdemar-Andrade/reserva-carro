/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.EstadoCivil;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class EstadoCivilDAO {

    public boolean cadastrarEstadoCivil(EstadoCivil estadoCivil) {

        String query_insert = "INSERT INTO estado_civil VALUES (DEFAULT, ?);";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setString(1, estadoCivil.getNome());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }

    public ArrayList<EstadoCivil> listarEstadoCivil() {
        ArrayList<EstadoCivil> estadoCivils = new ArrayList<>();
        String query = "SELECT pk_estado_civil, nome FROM estado_civil";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                EstadoCivil estadoCivil = new EstadoCivil();
                
                estadoCivil.setPk_estado_civil(rs.getInt(1));
                estadoCivil.setNome(rs.getString(2));

                estadoCivils.add(estadoCivil);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return estadoCivils;
    }

}
