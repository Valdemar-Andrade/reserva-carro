/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Pessoa;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class PessoaDAO {

    public boolean cadastrarPessoa(Pessoa pessoa) {

        String query_insert = "INSERT INTO pessoa(fk_usuario, nome) VALUES (?, ?);";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            /*
            ps.setInt(1, pessoa.getFk_usuario());
            ps.setInt(2, pessoa.getFk_sexo());
            ps.setInt(3, pessoa.getFk_estado_civil());
            ps.setInt(4, pessoa.getFk_residencia());
            ps.setString(5, pessoa.getNome());
            ps.setString(6, pessoa.getNumero_bi());
            ps.setString(7, pessoa.getData_nascimento());
            ps.setString(8, pessoa.getAltura());
             */
            ps.setInt(1, pessoa.getFk_usuario());
            ps.setString(2, pessoa.getNome());

            ps.execute();

            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
            return false;
        }
        return true;
    }

    public ArrayList<Pessoa> listarPessoa() {
        ArrayList<Pessoa> pessoas = new ArrayList<>();
        String query = "SELECT pk_pessoa, nome, fk_usuario FROM pessoa";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Pessoa pessoa = new Pessoa();

                pessoa.setPk_pessoa(rs.getInt(1));
                pessoa.setNome(rs.getString(2));
                pessoa.setFk_usuario(rs.getInt(3));

                pessoas.add(pessoa);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return pessoas;
    }

    //Consultar uma pessoa a partir da chave de um usuario
    public Pessoa getPessoaDeUsuario(int pk_usuario) {

        Pessoa pessoa = new Pessoa();
        ResultSet rs;

        //pk_pessoa, fk_usuario, nome
        String query = "SELECT pk_pessoa, fk_usuario, nome FROM pessoa WHERE fk_usuario=?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setInt(1, pk_usuario);

            rs = ps.executeQuery();

            if (rs.next()) {
                pessoa.setPk_pessoa(rs.getInt(1));
                pessoa.setFk_usuario(rs.getInt(2));
                pessoa.setNome(rs.getString(3));

                ps.close();
                rs.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        return pessoa;

    }

}
