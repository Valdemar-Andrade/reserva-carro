/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.ModeloCarro;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class ModeloCarroDAO {
    
    public boolean cadastrarModeloCarro(ModeloCarro modelo) {

        String query_insert = "INSERT INTO modelo_marca VALUES (DEFAULT, ?, ?);";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setString(1, modelo.getNome());
            ps.setInt(2, modelo.getFk_marca_carro());
            
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void atualizarModelo(String novaModelo, int pk_modelo){
        String query = "update modelo_marca set nome=? where pk_modelo_marca = ?";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setString(1, novaModelo);
            ps.setInt(2, pk_modelo);
            
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public void eliminar(int pk){
        String query = "delete from modelo_marca where pk_modelo_marca = ?";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setInt(1, pk);
            
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }
    
    public ArrayList<ModeloCarro> listarModeloCarro()
    {
        ArrayList<ModeloCarro> modelos = new ArrayList<>();
        String query = "SELECT pk_modelo_marca, nome, fk_marca FROM modelo_marca";
        
        try
        {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            while ( rs.next())
            {
                ModeloCarro modelo = new ModeloCarro();

                modelo.setPk_modelo_marca(rs.getInt(1));
                modelo.setNome(rs.getString(2));
                modelo.setFk_marca_carro(rs.getInt(3));

                modelos.add(modelo);
            }
        }
        catch(SQLException ex)
        {
            ex.getMessage();
        }
        return modelos;
    }
    
}
