/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Municipio;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class MunicipioDAO {
    
    public boolean cadastrarMunicipio(Municipio municipio) {

        String query_insert = "INSERT INTO localizacao_retirada VALUES (DEFAULT, ?, ?);";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setString(1, municipio.getNome());
            ps.setInt(2, municipio.getFk_provincia());
            
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public ArrayList<Municipio> listarMunicipio()
    {
        ArrayList<Municipio> municipios = new ArrayList<>();
        String query = "SELECT pk_localizacao, nome, fk_localizacao FROM localizacao_retirada";
        
        
        try
        {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            while ( rs.next())
            {
                if (rs.getInt(3) != 0){
                    
                    Municipio municipio = new Municipio();
                    
                    municipio.setPk_municipio(rs.getInt(1));
                    municipio.setNome(rs.getString(2));
                    municipio.setFk_provincia(rs.getInt(3));
                    
                    municipios.add(municipio);
                }
            }
            rs.close();
            ps.close();
            con.close();
        }
        catch(SQLException ex)
        {
            ex.getMessage();
        }
        return municipios;
    }
    
    public ArrayList<Municipio> listarMunicipiosDeUmaProvincia(int idProvincia)
    {
        ArrayList<Municipio> municipios = new ArrayList<>();
        String query = "SELECT pk_localizacao, nome, fk_localizacao FROM localizacao_retirada";
        
        
        try
        {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            while ( rs.next())
            {
                if (rs.getInt(3) != 0 && rs.getInt(3) == idProvincia){
                    
                    Municipio municipio = new Municipio();
                    
                    municipio.setPk_municipio(rs.getInt(1));
                    municipio.setNome(rs.getString(2));
                    municipio.setFk_provincia(rs.getInt(3));
                    
                    municipios.add(municipio);
                }
            }
            
            rs.close();
            ps.close();
        }
        catch(SQLException ex)
        {
            ex.getMessage();
        }
        return municipios;
    }
    
}
