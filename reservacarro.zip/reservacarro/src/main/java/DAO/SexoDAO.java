/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Sexo;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class SexoDAO {
    
    public boolean cadastrarSexo(Sexo sexo) {

        String query_insert = "INSERT INTO sexo VALUES (DEFAULT, ?);";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setString(1, sexo.getNome());
            
            ps.execute();
            System.out.println("Sexo inserido com sucesso!");
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public ArrayList<Sexo> listarSexo()
    {
        ArrayList<Sexo> sexos = new ArrayList<>();
        String query = "SELECT pk_sexo, nome FROM sexo";
        
        try
        {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            while ( rs.next())
            {
                Sexo sexo = new Sexo();
                sexo.setPk_sexo(rs.getInt(1));
                sexo.setNome(rs.getString(2));

                sexos.add(sexo);
            }
        }
        catch(SQLException ex)
        {
            ex.getMessage();
        }
        return sexos;
    }
    
}
