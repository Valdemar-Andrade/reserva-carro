/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.ReservaCarro;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class ReservaCarroDAO {

    public boolean cadastrarReservaCarro(ReservaCarro reservaCarro) {
        boolean retorno = false;

        String query_insert = "INSERT INTO reserva_carro VALUES (DEFAULT, ?, ?, ?, ?, ?, ?, ?);";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setInt(1, reservaCarro.getFk_pessoa());
            ps.setInt(2, reservaCarro.getFk_localizacao_retirada());
            ps.setInt(3, reservaCarro.getFk_carro());
            ps.setTimestamp(4, reservaCarro.getData_hora_retirada());
            ps.setTimestamp(5, reservaCarro.getData_hora_entrega());
            ps.setInt(6, reservaCarro.getFk_metodo_pagamento());
            ps.setFloat(7, reservaCarro.getValor_pago());

            retorno = ps.execute();

            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return retorno;
    }

    public ArrayList<ReservaCarro> listarReservaCarro() {
        ArrayList<ReservaCarro> reservaCarros = new ArrayList<>();
        String query = "SELECT pk_reserva_carro, fk_pessoa, fk_localizacao, fk_carro, data_hora_retirada, data_hora_entrega, fk_metodo_pagamento, valor_pago FROM reserva_carro";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                ReservaCarro reservaCarro = new ReservaCarro();

                reservaCarro.setPk_reserva(rs.getInt(1));
                reservaCarro.setFk_pessoa(rs.getInt(2));
                reservaCarro.setFk_localizacao_retirada(rs.getInt(3));
                reservaCarro.setFk_carro(rs.getInt(4));
                reservaCarro.setData_hora_retirada(rs.getTimestamp(5));
                reservaCarro.setData_hora_entrega(rs.getTimestamp(6));
                reservaCarro.setFk_metodo_pagamento(rs.getInt(7));
                reservaCarro.setValor_pago(rs.getFloat(8));

                reservaCarros.add(reservaCarro);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return reservaCarros;
    }

}
