/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import model.Usuario;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class LoginDAO {

    public Usuario verificarConta(String email, String senha) {
        //JOptionPane.showMessageDialog(null, "Verificar Conta\nEmail: " + email + "\nSenha: " + senha);
        //pk_usuario, fk_tipo_usuario, email, senha
        String query = "SELECT pk_usuario, fk_tipo_usuario, email, senha FROM usuario WHERE email=? AND senha=?";

        ResultSet rs;
        Usuario usuario = new Usuario();

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setString(1, email);
            ps.setString(2, senha);

            rs = ps.executeQuery();

            if (rs.next()) {
                usuario.setPk_usuario(rs.getInt(1));
                usuario.setFk_tipo_usuario(rs.getInt(2));
                usuario.setEmail(rs.getString(3));
                usuario.setSenha(rs.getString(4));

                rs.close();
                ps.close();
                con.close();
            }

        } catch (SQLException ex) {
            ex.getMessage();
        }

        return usuario;
    }

    public String tipoUsuario(int pk_tipo_usuario) {
        String tipoUsuario = "none", query;

        query = "SELECT nome FROM tipo_usuario WHERE pk_tipo_usuario=?";

        Connection con = Conexao.abrirConexao();
        ResultSet rs;

        try {

            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk_tipo_usuario);

            rs = ps.executeQuery();

            if (rs.next()) {
                tipoUsuario = rs.getString(1);

                ps.close();
                rs.close();
            }

        } catch (SQLException ex) {
            Logger.getLogger(LoginDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        //JOptionPane.showMessageDialog(null, "Funcao: TipoUsuario\nPk tipo_usuario: " + pk_tipo_usuario + "\nSaida tipoUsuario: " + tipoUsuario);
        return tipoUsuario;
    }

}
