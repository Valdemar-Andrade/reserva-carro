/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Carro;
import utils.Conexao;

/** 
 * @author valdemar
 */
public class CarroDAO {

    public boolean cadastrarCarro(Carro carro) {
        
        String query_insert = "INSERT INTO carro VALUES (DEFAULT, ?, ?, ?, ?);";

        try {

            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);

            ps.setInt(1, carro.getFk_modelo());
            ps.setInt(2, carro.getFk_classe());
            ps.setInt(3, carro.getNumero_lugares());
            ps.setFloat(4, carro.getPreco());
 
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public void atualizarCarro(float novaModelo, int pk_modelo) {
        String query = "update carro set preco=? where pk_carro = ?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setFloat(1, novaModelo);
            ps.setInt(2, pk_modelo);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public void eliminar(int pk) {
        String query = "delete from carro where pk_carro = ?";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);

            ps.setInt(1, pk);

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
    }

    public ArrayList<Carro> listarCarro() {
        ArrayList<Carro> carros = new ArrayList<>();
        String query = "SELECT pk_carro, fk_modelo, fk_classe, numero_lugares, preco FROM carro";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Carro carro = new Carro();

                carro.setPk_carro(rs.getInt(1));
                carro.setFk_modelo(rs.getInt(2));
                carro.setFk_classe(rs.getInt(3));
                carro.setNumero_lugares(rs.getInt(4));
                carro.setPreco(rs.getFloat(5));

                carros.add(carro);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return carros;
    }

    //
    public ArrayList<Carro> listarCarroDadosCompletos() {
        ArrayList<Carro> carros = new ArrayList<>();
        String query = "SELECT ca.pk_carro, ma.nome, mo.nome, cl.nome, ca.numero_lugares, ca.preco FROM carro ca join modelo_marca mo on ca.fk_modelo = mo.pk_modelo_marca join marca_carro ma on ma.pk_marca = mo.fk_marca join classe_carro cl on ca.fk_classe = cl.pk_classe";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Carro carro = new Carro();

                carro.setPk_carro(rs.getInt(1));
                carro.setMarca(rs.getString(2));
                carro.setModelo(rs.getString(3));
                carro.setClasse(rs.getString(4));
                carro.setNumero_lugares(rs.getInt(5));
                carro.setPreco(rs.getFloat(6));

                carros.add(carro);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return carros;
    }

    public ArrayList<Carro> listarCarroDadosCompletosComFiltro(String filtro) {
        ArrayList<Carro> carros = new ArrayList<>();
        String query = "";

        if (filtro != null) {

            if (filtro.equalsIgnoreCase("Economica")) {
                //Filtro (Classe do carro): economica - listagem em ordem crescente
                query = "SELECT ca.pk_carro, mo.nome, cl.nome, ca.numero_lugares, ca.preco FROM carro ca join modelo_marca mo on ca.fk_modelo = mo.pk_modelo_marca join classe_carro cl on ca.fk_classe = cl.pk_classe order by cl.nome";

            } else {
                //Filtro (Classe do carro): luxo - basta listar em ordem decrescente
                query = "SELECT ca.pk_carro, mo.nome, cl.nome, ca.numero_lugares, ca.preco FROM carro ca join modelo_marca mo on ca.fk_modelo = mo.pk_modelo_marca join classe_carro cl on ca.fk_classe = cl.pk_classe order by cl.nome desc";
            }
        }

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Carro carro = new Carro();

                carro.setPk_carro(rs.getInt(1));
                carro.setModelo(rs.getString(2));
                carro.setClasse(rs.getString(3));
                carro.setNumero_lugares(rs.getInt(4));
                carro.setPreco(rs.getFloat(5));

                carros.add(carro);
            }

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return carros;
    }

    public String getModeloCarro(int pk_modelo) {
        String query = "SELECT nome FROM modelo_marca WHERE pk_modelo_marca = " + pk_modelo + ";";
        String modelo = null;
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            modelo = rs.getString(1);

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return modelo;
    }

    public String getClasseCarro(int pk_classe) {

        String query = "SELECT nome FROM classe_carro WHERE pk_classe = " + pk_classe + ";";
        String modelo = null;
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            modelo = rs.getString(1);

            rs.close();
            ps.close();
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return modelo;
    }

}
