/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import model.Pessoa;
import model.PessoaAluguel;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class ConsultaDAO {

    public ArrayList<PessoaAluguel> listarPessoasComVendasRealizadas() {
        ArrayList<PessoaAluguel> pessoas = new ArrayList<>();
        
        String query = "SELECT pes.nome, mod.nome, cla.nome, ca.numero_lugares, ca.preco, res.data_hora_retirada, res.data_hora_entrega FROM pessoa pes JOIN reserva_carro res ON pes.pk_pessoa = res.fk_pessoa JOIN carro ca on ca.pk_carro=res.fk_carro JOIN classe_carro cla on cla.pk_classe=ca.fk_classe JOIN modelo_marca mod on mod.pk_modelo_marca=ca.fk_modelo";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                PessoaAluguel pessoa = new PessoaAluguel();
                
                //Nome ModeloCarro ClasseCarro Preco NumeroLugares DataRetirada DataEntrega
                pessoa.setNome(rs.getString(1));
                pessoa.setModelo_carro(rs.getString(2));
                pessoa.setClasse_carro(rs.getString(3));
                pessoa.setNumero_lugares(rs.getInt(4));
                pessoa.setPreco(rs.getFloat(5));
                pessoa.setData_hora_retirada(rs.getTimestamp(6));
                pessoa.setData_hora_entrega(rs.getTimestamp(7));
                
                pessoas.add(pessoa);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        
        return pessoas;
    }
    
    public ArrayList<PessoaAluguel> listarClientesPorIntervaloDeDatas(Timestamp data1, Timestamp data2){
        
        ArrayList<PessoaAluguel> pessoas = new ArrayList<>();
        
        //JOptionPane.showMessageDialog(null, "Listar Clientes Por Data\nData1: " + data1 + "\nData2: " + data2);
        
        //A Data em causa e a data_hora de retirada (Data em que o cliente foi pegar o carro na agencia)
        String query = "SELECT ps.pk_pessoa, ps.nome, rc.data_hora_retirada, rc.data_hora_entrega FROM reserva_carro rc JOIN pessoa ps ON ps.pk_pessoa = rc.fk_pessoa WHERE rc.data_hora_retirada BETWEEN ? AND ?";
        
        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            
            ps.setTimestamp(1, data1);
            ps.setTimestamp(2, data2);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                PessoaAluguel pessoa = new PessoaAluguel();
                
                pessoa.setPk_pessoa(rs.getInt(1));
                pessoa.setNome(rs.getString(2));
                pessoa.setData_hora_retirada(rs.getTimestamp(3));
                pessoa.setData_hora_entrega(rs.getTimestamp(4));
                
                pessoas.add(pessoa);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        
        return pessoas;
    }

}
