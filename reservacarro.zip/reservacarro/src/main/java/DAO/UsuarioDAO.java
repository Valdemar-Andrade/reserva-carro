/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Usuario;
import utils.Conexao;

/**
 *
 * @author valdemar
 */
public class UsuarioDAO {

    public boolean cadastrarUsuario(Usuario usuario) {

        String query_insert = "INSERT INTO usuario VALUES (DEFAULT, ?, ?, ?);";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setInt(1, usuario.getFk_tipo_usuario());
            ps.setString(2, usuario.getEmail());
            ps.setString(3, usuario.getSenha());

            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }

    public ArrayList<Usuario> listarUsuario() {
        ArrayList<Usuario> usuarios = new ArrayList<>();
        String query = "SELECT pk_usuario, email, senha, fk_tipo_usuario FROM usuario";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Usuario usuario = new Usuario();

                usuario.setPk_usuario(rs.getInt(1));
                usuario.setEmail(rs.getString(2));
                usuario.setSenha(rs.getString(3));
                usuario.setFk_tipo_usuario(rs.getInt(4));

                usuarios.add(usuario);
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }
        return usuarios;
    }

    public Usuario pegarUltimoUsuario() {

        Usuario usuario = new Usuario();

        String query = "SELECT max(pk_usuario) FROM usuario";

        try {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                usuario.setPk_usuario(rs.getInt(1));
            }
        } catch (SQLException ex) {
            ex.getMessage();
        }

        return usuario;

    }

}
