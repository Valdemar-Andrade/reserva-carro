/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import model.Provincia;
import utils.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


/**
 *
 * @author valdemar
 */
public class ProvinciaDAO {

    public boolean cadastrarProvincia(Provincia provincia) {

        String query_insert = "INSERT INTO localizacao_retirada VALUES (DEFAULT, ?, ?);";

        try {
            //Profundidade 0 para provincia
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query_insert);
            ps.setString(1, provincia.getNome());
            ps.setInt(2, 0);
            
            ps.execute();
            ps.close();
            con.close();

        } catch (SQLException ex) {
            ex.getMessage();
        }
        return false;
    }
    
    public ArrayList<Provincia> listarProvincia()
    {
        ArrayList<Provincia> provincias = new ArrayList<>();
        String query = "SELECT pk_localizacao, nome, fk_localizacao FROM localizacao_retirada";
        
        
        try
        {
            Connection con = Conexao.abrirConexao();
            PreparedStatement ps = con.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            
            while ( rs.next())
            {
                if (rs.getInt(3) == 0){
                    Provincia provincia = new Provincia();
                    provincia.setPk_provincia(rs.getInt(1));
                    provincia.setNome(rs.getString(2));
                    
                    provincias.add(provincia);
                }
            }
            
            rs.close();
            ps.close();
            con.close();
        }
        catch(SQLException ex)
        {
            ex.getMessage();
        }
        return provincias;
    }

}
